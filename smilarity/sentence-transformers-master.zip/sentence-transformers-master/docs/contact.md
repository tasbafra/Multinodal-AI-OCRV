# Contact

In case of questions, feel free to open a [Github Issue](https://github.com/UKPLab/sentence-transformers/issues) or write me an email: [info@nils-reimers.de](mailto:info@nils-reimers.de).

**SentenceTransformers is maintained by:**  
Nils Reimers  
Ubiquitous Knowledge Processing (UKP) Lab  
FB 20 / Department of Computer Science  
Technische Universität Darmstadt  
Hochschulstr. 10  
64289 Darmstadt  
Germany  
[Website](https://www.informatik.tu-darmstadt.de/ukp/ukp_home/index.en.jsp)


**Privacy Policy**  
The webserver / web hosting company might collect certain log files to prevent abuse of services. These log files can include: IP address, URL, date and time.

We do not use any tracking services or cookies to track or re-identify visitors. 